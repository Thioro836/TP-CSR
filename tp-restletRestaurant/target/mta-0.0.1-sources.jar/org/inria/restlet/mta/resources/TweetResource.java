package org.inria.restlet.mta.resources;

import org.inria.restlet.mta.database.InMemoryDatabase;
import org.inria.restlet.mta.internals.Tweet;
import org.inria.restlet.mta.internals.User;
import org.restlet.resource.ResourceException;
import org.restlet.resource.ServerResource;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.Put;


public class TweetResource extends ServerResource
{

    /** database. */
    private InMemoryDatabase db_;

    /** tweet géré par cette resource. */
    private Tweet tweet; 

    /**
     * Constructor.
     * Call for every single user request.
     */
    public TweetResource()
    {
        db_ = (InMemoryDatabase) getApplication().getContext().getAttributes()
                .get("database");
    }
    @Get("json")
    public Representation getTweet() throws Exception {
        String tweetIdString = (String) getRequest().getAttributes().get("twwetId");
        int twwetId = Integer.valueOf(tweetIdString);
        tweet = db_.getTweet(twwetId);
        //user 
       // String userIdString = (String) getRequest().getAttributes().get("userId");
        //int userId = Integer.valueOf(userIdString);
       // user = db_.getUser(userId);

        JSONObject tweetObject = new JSONObject();
        tweetObject.put("contenu", tweet.getContenu());
        tweetObject.put("id", tweet.getIdTweet());

        return new JsonRepresentation(tweetObject);
    }
}