package org.inria.restlet.mta.internals;

import java.security.Timestamp;

public class Tweet {
    //id du tweet
    private int id_tweet;
    //contenu du tweet
    private String contenu;
    //date 
    private Timestamp date;

    private User user;

    public Tweet(String contenu){
        this.contenu=contenu;
    }
    public String getContenu(){
        return this.contenu;
    }
    public void setContenu(String contenu){
        this.contenu=contenu;
    }

    public int getIdTweet()
    {
        return id_tweet;
    }

    public void setIdTweet(int id)
    {
        id_tweet = id;
    }

    
}
